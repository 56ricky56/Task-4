class KeyNotFoundException(Exception):
    pass

class Dict2:
    def __init__(self):
        self.data = {}

    def __setitem__(self, key, value):
        self.data[key] = value

    def __getitem__(self, key):
        if key in self.data:
            return self.data[key]
        else:
            raise KeyNotFoundException(f"Key '{key}' not found")

    def __iter__(self):
        return iter(self.data)

# Unit Test using unittest
import unittest

class TestDict2(unittest.TestCase):
    def test_store_key_value_pairs(self):
        obj = Dict2()
        obj['a'] = 1
        obj['b'] = 2
        obj['c'] = 3
        self.assertEqual(obj.data, {'a': 1, 'b': 2, 'c': 3})

    def test_access_values_by_key(self):
        obj = Dict2()
        obj['a'] = 1
        obj['b'] = 2
        obj['c'] = 3
        self.assertEqual(obj['a'], 1)
        self.assertEqual(obj['b'], 2)
        self.assertEqual(obj['c'], 3)

    def test_custom_exception_for_missing_key(self):
        obj = Dict2()
        with self.assertRaises(KeyNotFoundException):
            val = obj['a']

    def test_iterate_over_keys(self):
        obj = Dict2()
        obj['a'] = 1
        obj['b'] = 2
        obj['c'] = 3
        keys = [k for k in obj]
        self.assertEqual(keys, ['a', 'b', 'c'])

if __name__ == '__main__':
    unittest.main()
